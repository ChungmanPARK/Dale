﻿using Class_Library_Assignment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace parkAssignment
{
    public class Program
    {
        static Student[] students = {
            new Student("math", "06/May", 3),
            new Student("english", "08/Dec", 1),
            new Student("spanish", "11/Nov", 4),
            new Student("Science", "09/Oct", 2),
            new Student("Soccer", "09/Oct", 5),
            new Student("Badminton", "09/Oct", 7),
            new Student("Running", "09/Oct", 9),
            new Student("Racing", "09/Oct", 8),
            new Student("Science", "09/Oct", 11),
            new Student("math", "May/Jan", 10)
        };

        static Student node1 = new Student("math", "06/May", 3);
        static Student node2 = new Student("english", "08/Dec", 1);
        static Student node3 = new Student("Running", "09/Oct", 9);
        static Student node4 = new Student("Science", "09/Oct", 11);
        static Student node5 = new Student("Badminton", "09/Oct", 7);

        // Test in NUnit

        public static void TestSequentialSearch() 
        {
            Utility.NUnitSequentialSearch(students);
        }


        public static void TestBinarySearch()
        {
            Utility.NUnitBinarySearch(students);
        }

        public static void TestBubbleSort() 
        {
            Utility.NUnitBubbleSort(students);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Student Lists \n");
            for (int i = 0; i < students.Length; i++) // List of students 
            {
                Console.WriteLine(students[i] + " ");
            }

            // Sequential Search

            Console.WriteLine("\n Sequential Search");
            Utility.SequentialSearch(students);
            Console.WriteLine("\n");

            // Bubble Descending Students
            Console.WriteLine("Student Lists in Descending Order StudentID\n");
            Utility.BubbleSortDescending(students);
            for (int i = 0; i < students.Length; i++)
            {
                Console.WriteLine(students[i].StudentId);
            }

            // Bubble Sort in Ascending Order of students
            Console.WriteLine("Student Lists in Ascending Order StudentID\n");
            Utility.BubbleSortInAscending(students);
            for (int i = 0; i < students.Length; i++)
            {
                Console.WriteLine(students[i].StudentId);
            }




            Console.WriteLine("\n Binary Search");
            Utility.BinarySearch(students);
            Console.WriteLine("\n");


            DoubleLinkedList<Student> nodes = new DoubleLinkedList<Student>();
            Console.WriteLine("Double Linked List Test \n");
            // AddFirst nodes
            nodes.AddFirst(node3);
            nodes.AddFirst(node2);
            nodes.AddFirst(node1);
            Console.WriteLine("node 3, 2 and 1 are added at the First" + "\n");
            foreach (Student n in nodes)
            {
                Console.WriteLine("Program :" + n.Program + "DateRegistered :" + n.DateRegistered + "Student ID" + n.StudentId);
            }
            Console.WriteLine("\n");
            // AddLast nodes
            Console.WriteLine("node 4 and 5 are added at the last" + "\n");
            nodes.AddLast(node4);
            nodes.AddLast(node5);
            foreach (Student n in nodes)
            {
                Console.WriteLine("Program :" + n.Program + "DateRegistered :" + n.DateRegistered + "Student ID" + n.StudentId);
            }
            Console.WriteLine("\n");

            // Contain function
            Console.WriteLine("Contain function \n");
            Console.WriteLine(" node2 found True / False: " + nodes.Contains(node2));
            Console.WriteLine(" node4 found True / False: " + nodes.Contains(node5));

            foreach (Student n in nodes)
            {
                Console.WriteLine("Program :" + n.Program + "DateRegistered :" + n.DateRegistered + "Student ID" + n.StudentId);
            }
            Console.WriteLine("\n");

            // Remove First
            Console.WriteLine("First node will is deleted");
            nodes.RemoveFirst();
            foreach (Student n in nodes)
            {
                Console.WriteLine("Program :" + n.Program + "DateRegistered :" + n.DateRegistered + "Student ID" + n.StudentId);
            }
            Console.WriteLine("\n");

            // Remove Last
            Console.WriteLine("Last node will is deleted");
            nodes.RemoveFirst();
            foreach (Student n in nodes)
            {
                Console.WriteLine("Program :" + n.Program + "DateRegistered :" + n.DateRegistered + "Student ID" + n.StudentId);
            }
            Console.WriteLine("\n");



            


            // Test Single Linke List
            SingleLinkedList<Student> nodesForSingle = new SingleLinkedList<Student>();
            Console.WriteLine("Single Linked List Test \n");
            // AddFirst nodes
            nodesForSingle.AddFirst(node3);
            nodesForSingle.AddFirst(node2);
            nodesForSingle.AddFirst(node1);
            Console.WriteLine("node 3, 2 and 1 are added at the First" + "\n");
            foreach (Student n in nodesForSingle)
            {
                Console.WriteLine("Program :" + n.Program + "DateRegistered :" + n.DateRegistered + "Student ID" + n.StudentId);
            }
            Console.WriteLine("\n");
            // AddLast nodes
            Console.WriteLine("node 4 and 5 are added at the last" + "\n");
            nodesForSingle.AddLast(node4);
            nodesForSingle.AddLast(node5);
            foreach (Student n in nodesForSingle)
            {
                Console.WriteLine("Program :" + n.Program + "DateRegistered :" + n.DateRegistered + "Student ID" + n.StudentId);
            }
            Console.WriteLine("\n");

            // Contain function
            Console.WriteLine("Contain function \n");
            Console.WriteLine(" node2 found True / False: " + nodesForSingle.Contains(node2));
            Console.WriteLine(" node4 found True / False: " + nodesForSingle.Contains(node5));

            foreach (Student n in nodesForSingle)
            {
                Console.WriteLine("Program :" + n.Program + "DateRegistered :" + n.DateRegistered + "Student ID" + n.StudentId);
            }
            Console.WriteLine("\n");

            // Remove First
            Console.WriteLine("First node will is deleted");
            nodesForSingle.RemoveFirst();
            foreach (Student n in nodesForSingle)
            {
                Console.WriteLine("Program :" + n.Program + "DateRegistered :" + n.DateRegistered + "Student ID" + n.StudentId);
            }
            Console.WriteLine("\n");

            // Remove Last
            Console.WriteLine("Last node will is deleted");
            nodesForSingle.RemoveFirst();
            foreach (Student n in nodesForSingle)
            {
                Console.WriteLine("Program :" + n.Program + "DateRegistered :" + n.DateRegistered + "Student ID" + n.StudentId);
            }
            Console.WriteLine("\n");



            // Test Binary Tree
            BinaryTree binaryTree = new BinaryTree();
            // BinarySearch Tree
            binaryTree.Add(1);
            binaryTree.Add(2);
            binaryTree.Add(7);
            binaryTree.Add(3);
            binaryTree.Add(10);
            binaryTree.Add(5);
            binaryTree.Add(8);

            Node node = binaryTree.Find(5);
            int depth = binaryTree.GetTreeDepth();

            Console.WriteLine("PreOrder Traversal:");
            binaryTree.TraversePreOrder(binaryTree.Root);
            Console.WriteLine();

            Console.WriteLine("InOrder Traversal:");
            binaryTree.TraverseInOrder(binaryTree.Root);
            Console.WriteLine();

            Console.WriteLine("PostOrder Traversal:");
            binaryTree.TraversePostOrder(binaryTree.Root);
            Console.WriteLine();

            binaryTree.Remove(7);
            binaryTree.Remove(8);

            Console.WriteLine("PreOrder Traversal After Removing Operation:");
            binaryTree.TraversePreOrder(binaryTree.Root);
            Console.WriteLine();

            Console.ReadLine();
        }
    }
}
