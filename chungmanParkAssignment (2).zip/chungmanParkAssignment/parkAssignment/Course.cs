﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace parkAssignment
{
    class Course: IComparable<Course>
    {
        public string CourseCode { get; set; }
        public string CourseName { get; set; }
        public double Cost { get; set; }

        int IComparable<Course>.CompareTo(Course other)
        {
            return this.Cost.CompareTo(other.Cost);
        }
    }
}
