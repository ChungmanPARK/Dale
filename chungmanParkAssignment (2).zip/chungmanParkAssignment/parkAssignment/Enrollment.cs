﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace parkAssignment
{
    class Enrollment
    {
        public string Date_Enrolled { get; set; }
        public string Grade { get; set; }
        public string Semester { get; set; }
    }
}
